<?php
$angka=0;
$awal=1;
while($awal<=100){
	if($awal % 7 == 0){
		$angka=$awal;
		echo $angka;
		echo "</br>";
	}
		$awal++;
}

?>