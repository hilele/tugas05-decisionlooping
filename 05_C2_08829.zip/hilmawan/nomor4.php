<!DOCTYPE HTML>
<html>
<head></head>
<body>
	<form method="GET" action="nomor4.php">
		<select name="status">
			<option value="jomblo">JOMBLO</option>
			<option value="nikah">NIKAH</option>
		</select>
		<input type="text" name="gaji" placeholder="gaji">		
		<input type="submit" value="submit">
	</form>
<span id="hasil"></span>
</body>
</html>

<?php
if(isset($_GET['status']))
{
	$status=$_GET['status'];
}
else
{
	$status=null;
}
if(isset($_GET['gaji']))
{	
	$penghasilan=$_GET['gaji'];
}
else
{
	$penghasilan=null;
}

if($status=="jomblo")
{
	if($penghasilan>=0 && $penghasilan<=32000)
	{
		$total=$penghasilan*10/100;
		echo "pajaknya adalah 10%, dan total pajaknya sebesar : ".$total;
	}
	else
	{
		$total=($penghasilan*25/100)+3200;
		echo "pajaknya adalah 3200+25%, dan total pajaknya sebesar : ".$total;
	}
}
elseif($status=="nikah")
{
	if($penghasilan>=0 && $penghasilan<=64000)
	{
		$total=$penghasilan*10/100;
		echo "pajaknya adalah 10%, dan total pajaknya sebesar : ".$total;
	}
	else
	{
		$total=($penghasilan*25/100)+6400;
		echo "pajaknya adalah 6400+25%, dan total pajaknya sebesar : ".$total;
	}
}
?>