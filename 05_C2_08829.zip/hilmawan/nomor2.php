<?php
$bil_awal=1;
$hasil=0;
    while ($bil_awal <= 100) {
        if ($bil_awal % 2 != 0){
        $hasil = $hasil + $bil_awal;
    }
    $bil_awal++;
    }
    echo"Totalnya adalah $hasil";
?>